package com.eduscan.netscan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.eduscan.netscan.ui.nav.NetScanNavGraph
import com.eduscan.netscan.ui.theme.NetScanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NetScanTheme {
                NetScanNavGraph()
            }
        }
    }
}
