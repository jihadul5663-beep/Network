package com.eduscan.netscan.ui.theme

import androidx.compose.ui.graphics.Color

// Deep navy / near-black background gives the "network ops center" feel
val BgDeep = Color(0xFF0B1120)
val BgSurface = Color(0xFF121A2E)
val BgSurfaceElevated = Color(0xFF1A2440)
val BgCard = Color(0xFF16203A)

// Accent palette
val CyanAccent = Color(0xFF22D3EE)
val CyanAccentDim = Color(0xFF0E7490)
val PurpleAccent = Color(0xFF818CF8)
val IndigoAccent = Color(0xFF6366F1)

// Status colors
val StatusOpen = Color(0xFF34D399)     // open port / reachable device
val StatusClosed = Color(0xFF64748B)   // closed / filtered
val StatusWarning = Color(0xFFFBBF24)  // partial info
val StatusError = Color(0xFFF87171)    // error / unreachable

// Text
val TextPrimary = Color(0xFFE2E8F0)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BorderSubtle = Color(0xFF243154)
