package com.eduscan.netscan.network

/**
 * Lightweight well-known-ports table (subset of IANA registry).
 * Enough to label the vast majority of services found in the wild.
 */
object ServiceDatabase {

    private val portToService: Map<Int, String> = mapOf(
        20 to "FTP-DATA", 21 to "FTP", 22 to "SSH", 23 to "Telnet",
        25 to "SMTP", 37 to "TIME", 43 to "WHOIS", 53 to "DNS",
        67 to "DHCP", 69 to "TFTP", 70 to "Gopher", 79 to "Finger",
        80 to "HTTP", 88 to "Kerberos", 110 to "POP3", 111 to "RPCBind",
        113 to "Ident", 119 to "NNTP", 123 to "NTP", 135 to "MSRPC",
        137 to "NetBIOS-NS", 138 to "NetBIOS-DGM", 139 to "NetBIOS-SSN",
        143 to "IMAP", 161 to "SNMP", 162 to "SNMP-Trap", 179 to "BGP",
        194 to "IRC", 389 to "LDAP", 427 to "SLP", 443 to "HTTPS",
        445 to "SMB", 465 to "SMTPS", 500 to "IKE/IPSec", 514 to "Syslog",
        515 to "LPD", 543 to "Klogin", 544 to "Kshell", 548 to "AFP",
        554 to "RTSP", 587 to "SMTP-Submission", 631 to "IPP", 636 to "LDAPS",
        873 to "Rsync", 902 to "VMware-Auth", 993 to "IMAPS", 995 to "POP3S",
        1080 to "SOCKS", 1194 to "OpenVPN", 1433 to "MSSQL", 1521 to "Oracle-DB",
        1723 to "PPTP", 1883 to "MQTT", 2049 to "NFS", 2082 to "cPanel",
        2083 to "cPanel-SSL", 2181 to "Zookeeper", 2222 to "SSH-Alt",
        2375 to "Docker", 2376 to "Docker-TLS", 2483 to "Oracle-DB-Alt",
        3000 to "Dev-HTTP", 3128 to "Squid-Proxy", 3268 to "LDAP-GC",
        3306 to "MySQL", 3389 to "RDP", 3690 to "SVN", 4000 to "Dev-HTTP-Alt",
        4369 to "Erlang-EPMD", 4443 to "HTTPS-Alt", 5000 to "UPnP/Dev-HTTP",
        5001 to "Dev-HTTP", 5060 to "SIP", 5222 to "XMPP", 5353 to "mDNS",
        5432 to "PostgreSQL", 5555 to "ADB/Dev", 5601 to "Kibana",
        5672 to "AMQP", 5900 to "VNC", 5985 to "WinRM-HTTP", 5986 to "WinRM-HTTPS",
        6000 to "X11", 6379 to "Redis", 6443 to "Kubernetes-API",
        6667 to "IRC", 7001 to "WebLogic", 7077 to "Spark",
        8000 to "HTTP-Alt", 8008 to "HTTP-Alt", 8080 to "HTTP-Proxy",
        8081 to "HTTP-Alt", 8086 to "InfluxDB", 8443 to "HTTPS-Alt",
        8500 to "Consul", 8888 to "HTTP-Alt", 8983 to "Solr",
        9000 to "PHP-FPM/HTTP-Alt", 9042 to "Cassandra", 9092 to "Kafka",
        9100 to "Printer/JetDirect", 9200 to "Elasticsearch", 9300 to "Elasticsearch-Transport",
        10000 to "Webmin", 11211 to "Memcached", 15672 to "RabbitMQ-Mgmt",
        27017 to "MongoDB", 27018 to "MongoDB-Shard", 32400 to "Plex",
        49152 to "Windows-RPC-Dyn", 62078 to "iOS-Sync"
    )

    /** Curated ports most useful to scan by default - fast, high signal. */
    val commonPorts: List<Int> = listOf(
        21, 22, 23, 25, 53, 80, 88, 110, 111, 135, 139, 143, 161, 389,
        443, 445, 465, 514, 548, 587, 631, 636, 873, 993, 995,
        1433, 1521, 1723, 1883, 2049, 2082, 2083, 2181, 2375, 3000,
        3306, 3389, 5000, 5060, 5222, 5353, 5432, 5555, 5900, 5985,
        6379, 6443, 6667, 8000, 8008, 8080, 8081, 8086, 8443, 8888,
        8983, 9000, 9042, 9092, 9100, 9200, 10000, 11211, 15672,
        27017, 32400, 62078
    )

    /** Full "well-known" range per IANA convention. */
    val wellKnownRange: IntRange = 1..1023

    fun nameFor(port: Int): String = portToService[port] ?: "unknown"

    /** Ports where the server won't speak first - we should send an HTTP HEAD probe. */
    val httpLikePorts: Set<Int> = setOf(80, 443, 3000, 4443, 5000, 5001, 8000, 8008, 8080, 8081, 8443, 8888, 9000)

    /** Ports that are HTTP over TLS - need a plain HEAD probe sent after a TLS handshake. */
    val tlsPorts: Set<Int> = setOf(443, 4443, 8443, 993, 995, 465, 636)
}
