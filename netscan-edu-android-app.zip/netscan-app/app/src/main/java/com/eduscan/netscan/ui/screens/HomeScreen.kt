package com.eduscan.netscan.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eduscan.netscan.ui.components.GradientHeader
import com.eduscan.netscan.ui.components.SectionCard
import com.eduscan.netscan.ui.theme.*

@Composable
fun HomeScreen(
    onOpenPortScanner: () -> Unit,
    onOpenLocalNetwork: () -> Unit,
    onOpenAbout: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .verticalScroll(rememberScrollState())
    ) {
        GradientHeader(
            title = "NetScan Edu",
            subtitle = "Educational port scanning & network discovery toolkit"
        )

        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

            FeatureCard(
                icon = Icons.Filled.Radar,
                iconColor = CyanAccent,
                title = "Port & Service Scanner",
                description = "Scan an IP address or domain to find open ports, identify services, and grab version banners.",
                onClick = onOpenPortScanner
            )

            FeatureCard(
                icon = Icons.Filled.Devices,
                iconColor = PurpleAccent,
                title = "Local Network Scanner",
                description = "Discover devices connected to your WiFi network — IP, hostname, and vendor guess.",
                onClick = onOpenLocalNetwork
            )

            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.School, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("For educational use", color = TextPrimary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Only scan networks and devices you own or have explicit permission to test. " +
                        "Scanning systems without authorization may be illegal in your jurisdiction.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onOpenAbout, contentPadding = PaddingValues(0.dp)) {
                    Text("Read full disclaimer", color = CyanAccent)
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    SectionCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconColor)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(description, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextMuted)
        }
    }
}
