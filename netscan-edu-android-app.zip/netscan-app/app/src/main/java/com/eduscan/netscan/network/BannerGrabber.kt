package com.eduscan.netscan.network

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket
import java.nio.charset.StandardCharsets
import javax.net.ssl.SSLSocketFactory

/**
 * Best-effort banner grabbing, in the spirit of what `nmap -sV` does at a basic level:
 *  - Some protocols (SSH, FTP, SMTP, POP3, IMAP...) announce themselves the instant
 *    you connect, so we just read whatever the server sends first.
 *  - HTTP(S) servers wait for a request, so we send a minimal HEAD probe and read
 *    the "Server:" response header.
 *  - For TLS ports we perform the handshake first via SSLSocketFactory, then apply
 *    the same logic on the encrypted stream.
 */
object BannerGrabber {

    private const val READ_TIMEOUT_MS = 1500
    private val versionRegex = Regex("""(\d+\.\d+(\.\d+)?([.\-][A-Za-z0-9]+)?)""")

    data class BannerResult(val rawBanner: String?, val versionGuess: String?)

    fun grab(plainSocket: Socket, host: String, port: Int): BannerResult {
        return try {
            val socket: Socket = if (port in ServiceDatabase.tlsPorts) {
                wrapTls(plainSocket, host, port) ?: plainSocket
            } else {
                plainSocket
            }
            socket.soTimeout = READ_TIMEOUT_MS

            val banner = if (port in ServiceDatabase.httpLikePorts || port in ServiceDatabase.tlsPorts && isHttpPort(port)) {
                grabHttpBanner(socket, host)
            } else {
                grabPassiveBanner(socket)
            }

            BannerResult(banner, banner?.let { extractVersion(it) })
        } catch (e: Exception) {
            BannerResult(null, null)
        }
    }

    private fun isHttpPort(port: Int) = port in ServiceDatabase.httpLikePorts

    private fun wrapTls(socket: Socket, host: String, port: Int): Socket? {
        return try {
            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            factory.createSocket(socket, host, port, true)
        } catch (e: Exception) {
            null
        }
    }

    private fun grabPassiveBanner(socket: Socket): String? {
        return try {
            val input = socket.getInputStream()
            val buffer = ByteArray(512)
            val read = input.read(buffer)
            if (read <= 0) null else String(buffer, 0, read, StandardCharsets.ISO_8859_1).trim()
        } catch (e: Exception) {
            null
        }
    }

    private fun grabHttpBanner(socket: Socket, host: String): String? {
        return try {
            val out = socket.getOutputStream()
            val request = "HEAD / HTTP/1.1\r\nHost: $host\r\nUser-Agent: NetScanEdu/1.0\r\nConnection: close\r\n\r\n"
            out.write(request.toByteArray(StandardCharsets.US_ASCII))
            out.flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), StandardCharsets.ISO_8859_1))
            val lines = mutableListOf<String>()
            var line: String?
            var count = 0
            while (reader.readLine().also { line = it } != null && count < 30) {
                line?.let { lines.add(it) }
                if (line.isNullOrEmpty()) break
                count++
            }
            if (lines.isEmpty()) return null

            // Prefer the Server header if present; otherwise fall back to the status line.
            val serverHeader = lines.firstOrNull { it.startsWith("Server:", ignoreCase = true) }
            (serverHeader ?: lines.first()).trim()
        } catch (e: Exception) {
            null
        }
    }

    private fun extractVersion(banner: String): String? {
        val match = versionRegex.find(banner) ?: return null
        // Grab a short window of context around the version number for readability.
        val idx = banner.indexOf(match.value)
        val start = maxOf(0, idx - 15)
        val end = minOf(banner.length, idx + match.value.length + 5)
        return banner.substring(start, end).trim().trim('/', '-', ' ')
    }
}
