package com.eduscan.netscan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.eduscan.netscan.model.NetworkDevice
import com.eduscan.netscan.ui.components.*
import com.eduscan.netscan.ui.theme.*
import com.eduscan.netscan.viewmodel.LocalNetworkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalNetworkScreen(onBack: () -> Unit, viewModel: LocalNetworkViewModel = viewModel()) {
    val context = LocalContext.current
    val state = viewModel.uiState

    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopAppBar(
                title = { Text("Local Network Scanner") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgSurfaceElevated, titleContentColor = TextPrimary, navigationIconContentColor = TextPrimary)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {

            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("This device", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            state.localIp ?: "—",
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (state.subnetCidr != null) {
                            Text("Subnet: ${state.subnetCidr}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Button(
                        onClick = { viewModel.startScan(context) },
                        enabled = !state.isScanning,
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent, contentColor = BgDeep)
                    ) {
                        if (state.isScanning) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = BgDeep, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Devices, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Scan")
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            if (state.error != null) {
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusError)
                        Spacer(Modifier.width(8.dp))
                        Text(state.error, color = StatusError, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            if (state.hostsTotal > 0) {
                ScanProgressBar(state.hostsScanned, state.hostsTotal)
                Spacer(Modifier.height(14.dp))
            }

            if (state.devices.isEmpty() && state.finished && state.error == null) {
                EmptyState(
                    icon = { Icon(Icons.Filled.WifiFind, contentDescription = null, tint = TextMuted, modifier = Modifier.size(40.dp)) },
                    title = "No devices found",
                    subtitle = "Nothing responded on the subnet. Some devices may block discovery."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.devices) { device ->
                        DeviceCard(device)
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun DeviceCard(device: NetworkDevice) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.DeviceUnknown,
                contentDescription = null,
                tint = StatusOpen,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(device.ip, color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                val subtitle = device.deviceTypeGuess ?: device.hostname ?: "Unidentified device"
                Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)

                Spacer(Modifier.height(6.dp))
                Row {
                    if (device.macAddress != null) {
                        PortStatusChip(device.macAddress, PurpleAccent)
                        Spacer(Modifier.width(6.dp))
                    }
                    if (device.vendorGuess != null) {
                        PortStatusChip(device.vendorGuess, CyanAccent)
                    }
                }
            }
            if (device.responseTimeMs != null) {
                Text("${device.responseTimeMs}ms", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
