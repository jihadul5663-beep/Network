package com.eduscan.netscan.model

/** Result of probing a single TCP port on a target host. */
data class PortResult(
    val port: Int,
    val serviceName: String,      // e.g. "SSH", "HTTP" - from the well-known-ports table
    val banner: String?,          // raw banner text captured from the socket, if any
    val versionGuess: String?,    // best-effort version string parsed out of the banner
    val responseTimeMs: Long
)

/** Overall state of a port scan against a single host. */
data class PortScanUiState(
    val isScanning: Boolean = false,
    val hostInput: String = "",
    val resolvedIp: String? = null,
    val resolutionError: String? = null,
    val portsScanned: Int = 0,
    val portsTotal: Int = 0,
    val openPorts: List<PortResult> = emptyList(),
    val finished: Boolean = false
)

enum class PortRangeMode { COMMON, WELL_KNOWN, CUSTOM }

/** A device discovered on the local subnet. */
data class NetworkDevice(
    val ip: String,
    val hostname: String?,        // reverse-DNS / DHCP hostname, if resolvable
    val macAddress: String?,      // from ARP table, best-effort (often unavailable on Android 10+)
    val vendorGuess: String?,     // from MAC OUI lookup
    val deviceTypeGuess: String?, // heuristic guess parsed from hostname (e.g. "Apple device")
    val responseTimeMs: Long?,
    val isThisDevice: Boolean = false
)

data class LocalScanUiState(
    val isScanning: Boolean = false,
    val subnetCidr: String? = null,
    val localIp: String? = null,
    val hostsScanned: Int = 0,
    val hostsTotal: Int = 0,
    val devices: List<NetworkDevice> = emptyList(),
    val error: String? = null,
    val finished: Boolean = false
)
